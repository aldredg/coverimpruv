import { CoverAnalyzer } from "@/components/cover-analyzer"

export default function UploadPage() {
  return (
    <div className="min-h-screen bg-background">
      <CoverAnalyzer />
    </div>
  )
}
