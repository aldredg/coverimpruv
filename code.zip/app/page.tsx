import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Upload, Eye, TrendingUp } from "lucide-react"

export default function Page() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold tracking-tight">
            CoverImpruv
          </Link>
          <nav className="flex items-center gap-6">
            <Link href="/pricing" className="text-sm font-medium hover:text-foreground/80 transition-colors">
              Pricing
            </Link>
            <Link href="/examples" className="text-sm font-medium hover:text-foreground/80 transition-colors">
              Examples
            </Link>
            <Link href="/api/auth/signin" className="text-sm font-medium hover:text-foreground/80 transition-colors">
              Login
            </Link>
            <Button asChild size="sm">
              <Link href="/upload">Get Started</Link>
            </Button>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="container mx-auto px-4 py-24 text-center">
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6 text-balance">
            Don't Guess. Know How Your Book Cover Sells.
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto text-balance">
            Upload your cover & see it in a realistic Amazon-style search results page
          </p>
          <Button asChild size="lg" className="text-lg px-8 py-6">
            <Link href="/upload">Get Started - It's Free</Link>
          </Button>
        </section>

        {/* Features Section */}
        <section className="container mx-auto px-4 py-16">
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Upload className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Upload</h3>
              <p className="text-muted-foreground">Drag and drop your book cover or browse to upload</p>
            </div>

            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Eye className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Preview</h3>
              <p className="text-muted-foreground">See your cover in realistic Amazon search results</p>
            </div>

            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                <TrendingUp className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Improve</h3>
              <p className="text-muted-foreground">Get AI-powered analysis and actionable insights</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border/40 py-8 mt-16">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 CoverImpruv. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
