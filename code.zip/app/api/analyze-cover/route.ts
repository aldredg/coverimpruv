import { generateText } from "ai"

export async function POST(req: Request) {
  try {
    const { image } = await req.json()

    const result = await generateText({
      model: "openai/gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Act as Amazon KDP cover expert for Thriller genre. Analyze this book cover and provide a score from 0-100. Provide exactly 4 bullet points covering: 1) Thumbnail Legibility, 2) Genre Fit, 3) Color Contrast, 4) Visual Hierarchy. Be harsh but constructive. Format your response as JSON with keys: score (number), thumbnailLegibility (string), genreFit (string), colorContrast (string), visualHierarchy (string).",
            },
            {
              type: "image",
              image,
            },
          ],
        },
      ],
      maxOutputTokens: 1000,
    })

    const jsonMatch = result.text.match(/\{[\s\S]*\}/)
    if (jsonMatch) {
      const analysis = JSON.parse(jsonMatch[0])
      return Response.json(analysis)
    }

    return Response.json(
      {
        score: 0,
        thumbnailLegibility: "Unable to analyze",
        genreFit: "Unable to analyze",
        colorContrast: "Unable to analyze",
        visualHierarchy: "Unable to analyze",
      },
      { status: 500 },
    )
  } catch (error) {
    console.error("Analysis error:", error)
    return Response.json(
      {
        score: 0,
        thumbnailLegibility: "Analysis failed",
        genreFit: "Analysis failed",
        colorContrast: "Analysis failed",
        visualHierarchy: "Analysis failed",
      },
      { status: 500 },
    )
  }
}
