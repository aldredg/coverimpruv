"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Upload, Loader2 } from "lucide-react"
import Link from "next/link"

const AMAZON_THRILLER_COVERS = [
  "https://m.media-amazon.com/images/I/71k3g1JiLsL._AC_UY218_.jpg",
  "https://m.media-amazon.com/images/I/81h2J7wGmjL._AC_UY218_.jpg",
  "https://m.media-amazon.com/images/I/81N7Fm6hvvL._AC_UY218_.jpg",
  "https://m.media-amazon.com/images/I/91r5G8qTBuL._AC_UY218_.jpg",
  "https://m.media-amazon.com/images/I/81WaCUGdyJL._AC_UY218_.jpg",
  "https://m.media-amazon.com/images/I/81kzoq2kGBL._AC_UY218_.jpg",
  "https://m.media-amazon.com/images/I/71yYa9i2ZEL._AC_UY218_.jpg",
  "https://m.media-amazon.com/images/I/81WcnNq6URL._AC_UY218_.jpg",
]

interface AnalysisResult {
  score: number
  thumbnailLegibility: string
  genreFit: string
  colorContrast: string
  visualHierarchy: string
}

export function CoverAnalyzer() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null)

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)

    const file = e.dataTransfer.files[0]
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setUploadedImage(e.target?.result as string)
        setAnalysis(null)
      }
      reader.readAsDataURL(file)
    }
  }, [])

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setUploadedImage(e.target?.result as string)
        setAnalysis(null)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const runAnalysis = async () => {
    if (!uploadedImage) return

    setIsAnalyzing(true)
    try {
      const response = await fetch("/api/analyze-cover", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: uploadedImage }),
      })

      const data = await response.json()
      setAnalysis(data)
    } catch (error) {
      console.error("Analysis failed:", error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  const gridCovers = AMAZON_THRILLER_COVERS.slice(0, 2)
    .concat([uploadedImage || ""])
    .concat(AMAZON_THRILLER_COVERS.slice(2))

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold tracking-tight">
            CoverImpruv
          </Link>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-2">Analyze Your Book Cover</h1>
            <p className="text-muted-foreground">See how your cover performs in Amazon search results</p>
          </div>

          {!uploadedImage ? (
            <Card className="p-8">
              <div
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
                  isDragging ? "border-primary bg-primary/5" : "border-border"
                }`}
              >
                <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-xl font-semibold mb-2">Upload Your Book Cover</h3>
                <p className="text-muted-foreground mb-4">Drag and drop your cover image here, or click to browse</p>
                <input type="file" accept="image/*" onChange={handleFileInput} className="hidden" id="file-upload" />
                <Button asChild>
                  <label htmlFor="file-upload" className="cursor-pointer">
                    Browse Files
                  </label>
                </Button>
              </div>
            </Card>
          ) : (
            <>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Amazon Search Results Preview</h2>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setUploadedImage(null)
                        setAnalysis(null)
                      }}
                    >
                      Re-upload
                    </Button>
                    <Button onClick={runAnalysis} disabled={isAnalyzing}>
                      {isAnalyzing ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        "Run AI Analysis"
                      )}
                    </Button>
                  </div>
                </div>

                <Card className="p-6 bg-white">
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    {gridCovers.map((cover, index) => (
                      <div
                        key={index}
                        className={`relative aspect-[2/3] ${
                          index === 2 && uploadedImage ? "ring-4 ring-blue-500 rounded" : ""
                        }`}
                      >
                        {cover ? (
                          <img
                            src={cover || "/placeholder.svg"}
                            alt={`Book cover ${index + 1}`}
                            className="w-full h-full object-cover rounded shadow-sm"
                          />
                        ) : (
                          <div className="w-full h-full bg-muted rounded flex items-center justify-center">
                            <Upload className="w-8 h-8 text-muted-foreground" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </Card>
              </div>

              {analysis && (
                <Card className="p-6">
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h2 className="text-2xl font-bold">Analysis Report</h2>
                      <div className="text-4xl font-bold text-primary">{analysis.score}/100</div>
                    </div>

                    <div className="grid gap-4">
                      <div className="space-y-2">
                        <h3 className="font-semibold flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-primary"></span>
                          Thumbnail Legibility
                        </h3>
                        <p className="text-muted-foreground pl-4">{analysis.thumbnailLegibility}</p>
                      </div>

                      <div className="space-y-2">
                        <h3 className="font-semibold flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-primary"></span>
                          Genre Fit
                        </h3>
                        <p className="text-muted-foreground pl-4">{analysis.genreFit}</p>
                      </div>

                      <div className="space-y-2">
                        <h3 className="font-semibold flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-primary"></span>
                          Color Contrast
                        </h3>
                        <p className="text-muted-foreground pl-4">{analysis.colorContrast}</p>
                      </div>

                      <div className="space-y-2">
                        <h3 className="font-semibold flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-primary"></span>
                          Visual Hierarchy
                        </h3>
                        <p className="text-muted-foreground pl-4">{analysis.visualHierarchy}</p>
                      </div>
                    </div>
                  </div>
                </Card>
              )}
            </>
          )}
        </div>
      </main>
    </div>
  )
}
